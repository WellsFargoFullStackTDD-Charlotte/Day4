﻿/// <reference path="mocha.js" />
/// <reference path="../chai/chai.js" />

var assert = chai.assert;
it("Mocha Chai with Assert", function () {
    var foo = "bar";

    assert.typeOf(foo, 'string');
    assert.equal(foo, 'bar');
    assert.lengthOf(foo, 3);
});

var expect = chai.expect;
it("Mocha Chai with Expect", function () {
    var foo = "bar";

    expect(foo).to.be.a('string');
    expect(foo).to.equal('bar');
    expect(foo).to.have.length(3);
});

chai.should();
it("Mocha Chai with Should", function () {
    var foo = "bar";

    foo.should.be.a('string');
    foo.should.equal('bar');
    foo.should.have.length(3);
});

